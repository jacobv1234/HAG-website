This version introduces the contact page, but does not have an admin panel to change the destination address.

To change the destination:

Open 'receiver.txt', and replace the contents with your email.
Do NOT press Enter afterwards, and make sure you don't have 'sender.txt' by mistake.
Press Ctrl+S to save, then close Notepad.